#!/usr/bin/env python3
"""
glk_protocol.py  --  Awesom Living canonical reference for the GLK AI Smart
Sleep Monitor (WiFi-compact variant), Sleep-to-Cloud TCP protocol + BLE
provisioning.

WHY THIS FILE EXISTS
--------------------
Integrating the GLK monitor took ~3 weeks because the real WiFi device deviates
from the supplier protocol PDF in several non-obvious ways. The PDF describes the
4G variant; the device we ship is the WiFi-compact variant. Every byte layout and
rule below was VERIFIED against live packet captures (glk_ours.pcap / glk_cloud.pcap),
not copied from the PDF examples. Treat THIS file as the source of truth.

This module is intentionally dependency-free (stdlib only) so it can be dropped
onto any fresh Raspberry Pi and used directly by glk_bridge.py, or run standalone
as a self-test:

    python3 glk_protocol.py --selftest

SCOPE
-----
Fully implemented & self-tested (this is where ALL the historical bugs lived):
  - Frame envelope + XOR checksum
  - Packed-BCD serial number encode/decode
  - Login (0x03) parse + Login ACK build
  - Device Info (0x04) parse (compact 18-byte) + Device Info ACK build
  - Sleep Stage (0x4E) ACK build (v23, verified against firmware v0570)
  - BLE provisioning packet builder (0x1F WiFi, 0x23 server) with chunking

Documented hooks (these never needed fixing — the connection handshake did):
  - Time Sync (0x02) ACK: envelope is standard; carry current time per device.
  - Realtime (0x0E) field decode: the field SET is known and listed; keep the
    working byte-offset decode from the tested glk_bridge.py. Do NOT re-derive
    offsets from scratch — the 0x0E parser was never the problem.
"""

from __future__ import annotations
import struct
import time as _time
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Frame envelope
# ---------------------------------------------------------------------------
# On-wire frame (Sleep-to-Cloud, TCP):
#
#     0x82 | len | ack | seq | cmd | ...payload... | xor_checksum
#       0     1     2     3     4     5 .. (n-1)         n
#
#   - 0x82            : fixed start byte
#   - len             : number of bytes AFTER this length byte, INCLUDING the
#                       checksum. So total frame length on wire = 2 + len.
#   - ack             : ack flag (0x01 observed)
#   - seq             : 1-byte sequence, wraps 0x00..0xFF (wrap is normal)
#   - cmd             : command byte (see CMD_*)
#   - xor_checksum    : XOR of EVERY byte from 0x82 through the last payload
#                       byte (i.e. the whole frame except the checksum itself).
#
# VERIFIED on real frames (see --selftest):
#   Login (compact, 12B):
#     82 0A 01 A6 03  33 20 14 81 30 81  1B
#   Device Info (compact WiFi, 18B):
#     82 10 01 55 04  33 20 14 81 30 81  05 70  D6 00 00 00  56

FRAME_START = 0x82

CMD_LOGIN        = 0x03   # device -> server, on connect
CMD_TIME_SYNC    = 0x02   # device -> server, asked once after login
CMD_DEVICE_INFO  = 0x04   # device -> server, compact 18B on the WiFi variant
CMD_REALTIME     = 0x0E   # device -> server, ~1 Hz vitals once a person is on pad
CMD_SLEEP_STAGE  = 0x4E   # device -> server, staging (valid only over a full night)
CMD_EMERGENCY    = 0x0D   # device -> server, emergency event


def xor_checksum(data: bytes) -> int:
    """XOR of all bytes in `data`. For a frame, pass everything EXCEPT the
    trailing checksum byte (the 0x82 start byte IS included)."""
    c = 0
    for b in data:
        c ^= b
    return c


def build_frame(seq: int, cmd: int, payload: bytes = b"", ack: int = 0x01) -> bytes:
    """Assemble a complete on-wire frame with correct len byte and XOR checksum."""
    body = bytes([ack & 0xFF, seq & 0xFF, cmd & 0xFF]) + payload
    # len counts ack+seq+cmd+payload+checksum = len(body) + 1 (checksum)
    length = len(body) + 1
    head = bytes([FRAME_START, length & 0xFF]) + body
    return head + bytes([xor_checksum(head)])


def parse_frame(frame: bytes) -> dict | None:
    """Validate envelope + checksum and split into fields. Returns None on any
    structural/checksum failure (caller should log & drop)."""
    if len(frame) < 6 or frame[0] != FRAME_START:
        return None
    length = frame[1]
    total = 2 + length
    if len(frame) < total:
        return None  # short read; wait for more bytes
    frame = frame[:total]
    if xor_checksum(frame[:-1]) != frame[-1]:
        return None  # checksum mismatch
    return {
        "ack": frame[2],
        "seq": frame[3],
        "cmd": frame[4],
        "payload": frame[5:-1],
        "checksum": frame[-1],
        "raw": frame,
    }


# ---------------------------------------------------------------------------
# Serial number  (packed BCD: each byte's two hex nibbles ARE the decimal digits)
# ---------------------------------------------------------------------------
#   bytes 33 20 14 81 30 81  ->  "33"+"20"+"14"+"81"+"30"+"81"  ->  "332014813081"

def sn_decode(b: bytes) -> str:
    return "".join(f"{x:02X}" for x in b)

def sn_encode(s: str) -> bytes:
    s = s.strip()
    if len(s) % 2:
        raise ValueError("SN must be an even number of digits")
    return bytes(int(s[i:i + 2], 16) for i in range(0, len(s), 2))


# ---------------------------------------------------------------------------
# Login (0x03)
# ---------------------------------------------------------------------------
# Compact login frame is 12 bytes total and carries NO verification code:
#     82 0A 01 A6 03 | <SN 6B> | <xor>
# CRITICAL: earlier code assumed it had to echo a "login code" from this frame.
# There is no code here. The server ASSIGNS the 4-byte code in the login ACK.

def parse_login(frame: dict) -> dict:
    p = frame["payload"]
    return {"sn": sn_decode(p[0:6]) if len(p) >= 6 else None}

def build_login_ack(seq: int, code: bytes | None = None) -> bytes:
    """Login ACK assigns a 4-byte code to the device.
    The device stores this code and echoes it back in every Time Sync request.
    Default: current Unix timestamp (big-endian). The old hardcoded value
    (0x5E0964B8 = Jan 2020) caused Time Sync loops because the device echoed
    a stale epoch that never matched the current time.
    """
    if code is None:
        code = struct.pack(">I", int(_time.time()))
    if len(code) != 4:
        raise ValueError("login code must be exactly 4 bytes")
    return build_frame(seq, CMD_LOGIN, payload=code)


# ---------------------------------------------------------------------------
# Device Info (0x04)  --  THE bug that cost the most time
# ---------------------------------------------------------------------------
# The WiFi-compact device sends an 18-byte frame:
#     82 10 01 55 04 | <SN 6B> | <fw 2B> | <code 4B> | <xor>
#                       5..10      11..12    13..16      17
# The PDF documents the 53-byte 4G layout (FW/HW/CSQ/CCID). The original bridge
# guarded with `if len(frame) < 52: return None`, so it SILENTLY DROPPED the
# 18-byte frame, never ACKed it, and the device retried 7x then disconnected
# every ~60s. THE FIX: accept length >= 18 and read the compact offsets below.

def parse_device_info(frame: dict) -> dict:
    """Accepts the compact 18-byte WiFi variant. (Offsets are into the full raw
    frame.) An optional >=52 branch can be added later for the 4G variant."""
    raw = frame["raw"]
    if len(raw) < 18:
        return {}  # too short to be the compact device-info frame
    return {
        "sn": sn_decode(raw[5:11]),          # bytes 5..10
        "firmware": raw[11:13].hex(),        # bytes 11..12  e.g. "0570"
        "verification_code": raw[13:17].hex(),  # bytes 13..16 (device-chosen / echoed)
        "device_type": "wifi-compact",
    }

def build_device_info_ack(seq: int) -> bytes:
    """Minimal positive ACK for the device-info frame. Sending ANY valid ACK is
    what stops the 60-second reconnect loop."""
    return build_frame(seq, CMD_DEVICE_INFO, payload=b"\x00")


# ---------------------------------------------------------------------------
# Time Sync (0x02)  --  standard envelope; payload carries current time
# ---------------------------------------------------------------------------
# ROOT CAUSE of the 7x Time Sync loop that prevented vitals streaming:
#   The device sends a 4-byte payload in its Time Sync request (the code
#   assigned during Login ACK). The bridge was responding with a 6-byte
#   packed-BCD payload (YY MM DD HH MM SS). The PAYLOAD LENGTH MISMATCH
#   caused the device to reject every Time Sync ACK, retry 7 times, and
#   disconnect.
#
# FIX: respond with a 4-byte big-endian Unix timestamp — same length the
# device expects, and meaningful as a time value.

def build_time_sync_ack(seq: int, when: datetime | None = None) -> bytes:
    """Time Sync ACK with 4-byte big-endian Unix timestamp.
    The device sends 4 bytes in its Time Sync request; responding with the
    same length (4 bytes) is critical — the old 6-byte BCD payload caused
    the device to loop 7 times and disconnect."""
    if when is not None:
        epoch = int(when.timestamp())
    else:
        epoch = int(_time.time())
    payload = struct.pack(">I", epoch)
    return build_frame(seq, CMD_TIME_SYNC, payload=payload)


def build_time_sync_ack_bcd(seq: int, when: datetime | None = None) -> bytes:
    """DEPRECATED: 6-byte packed-BCD format. Kept for reference/testing only.
    DO NOT USE IN PRODUCTION — causes the 7x Time Sync loop."""
    when = when or datetime.now(timezone.utc)
    bcd = lambda n: int(f"{n:02d}", 16)
    payload = bytes([
        bcd(when.year % 100), bcd(when.month), bcd(when.day),
        bcd(when.hour), bcd(when.minute), bcd(when.second),
    ])
    return build_frame(seq, CMD_TIME_SYNC, payload=payload)


# ---------------------------------------------------------------------------
# Sleep Stage (0x4E)  --  ACK is REQUIRED or device disconnects
# ---------------------------------------------------------------------------
# Verified 2026-09-03: without this ACK the device disconnects after sending
# one 0x4E frame and reconnects ~60s later. The ACK format is:
#     82 05 00 <seq> 4E 01 <xor>
# ack=0x00 (response), payload=0x01 (success).

def build_sleep_stage_ack(seq: int) -> bytes:
    """Build 0x4E sleep stage ACK. Required by protocol — without this the
    device disconnects after every sleep stage frame."""
    return build_frame(seq, CMD_SLEEP_STAGE, payload=b"\x01", ack=0x00)


# ---------------------------------------------------------------------------
# Realtime (0x0E)  --  field SET is known; KEEP the tested offset decode
# ---------------------------------------------------------------------------
# Once the connection holds, 0x0E frames arrive ~1 Hz. The decoded fields the
# backend already consumes are:
#     heart_rate, respiration_rate, status_code -> status (in_bed/out_of_bed/
#     apnea_suspected), in_bed, out_of_bed, snoring, body_movement,
#     apnea_suspected, life_abnormality, battery_level
# Behaviour to expect (verified in live data):
#     - HR ~ 52-93, RR ~ 11-15 at rest.
#     - When apnea_suspected is set, respiration_rate comes back null (sensible).
#     - status_code 4 == out_of_bed.
#     - sleep_stage is "invalid" until a real full night accumulates.
# The 0x0E byte-offset decode in the tested glk_bridge.py WORKS and was never
# the source of any bug -- do not rewrite it from the PDF. Wire it in here:
def parse_realtime(frame: dict) -> dict:
    raise NotImplementedError(
        "Use the verified 0x0E field decode from the tested glk_bridge.py. "
        "The fields are listed in this function's docstring; the offsets were "
        "never broken, so they are intentionally not re-derived here."
    )


# ===========================================================================
# BLE PROVISIONING  (one-time setup; sleep data does NOT come over BLE)
# ===========================================================================
# BLE is SETUP ONLY: write WiFi creds (0x1F) and server config (0x23). After
# that the device joins WiFi and streams over TCP to the Pi on port 8766.
#
# GATT:
#   service fff0 ; write config to fff1 (app->device) ; subscribe fff2 (replies)
#   Advertising name = "LZ-OTA <12-digit serial>"  (this is NORMAL provisioning
#   mode, not a bootloader).
#   DO NOT write to FE59 / 8EC9... -- that is the DFU bootloader hook. Never
#   flash firmware; it is not needed.
#
# BLE config packet (from Bluetooth_protocol_V1.0.1, GLK-RD-IPR-051):
#   CD | msgType(1) | length(2, BIG-endian) | content(n, ASCII) | crc32(4)
#   where  length = n + 4   and   crc may be FF FF FF FF (device ignores it).
#   Content is comma-joined, quoted values:  "VAL1","VAL2"
#   WRITES MUST BE CHUNKED to <= 20 bytes per BLE write.
#
# COMMON MISTAKE (cost us time): copying the length byte from a PDF example
# instead of computing length = len(content) + 4. Always compute it.

BLE_SERVICE_UUID = "0000fff0-0000-1000-8000-00805f9b34fb"
BLE_WRITE_CHAR    = "0000fff1-0000-1000-8000-00805f9b34fb"  # app -> device
BLE_NOTIFY_CHAR   = "0000fff2-0000-1000-8000-00805f9b34fb"  # device -> app
BLE_FORBIDDEN     = ("fe59", "8ec9")  # NEVER write here (DFU bootloader)

BLE_MSG_WIFI   = 0x1F   # "<SSID>","<PASSWORD>"
BLE_MSG_SERVER = 0x23   # "<PI_IP>","<PORT>"

def ble_content(*values: str) -> bytes:
    """Build the comma-joined quoted ASCII content, e.g. '"SSID","PWD"'."""
    return ",".join(f'"{v}"' for v in values).encode("ascii")

def build_ble_config(msg_type: int, *values: str) -> bytes:
    """Build a full (unchunked) BLE config packet. length = content + 4."""
    content = ble_content(*values)
    length = len(content) + 4
    return (bytes([0xCD, msg_type & 0xFF])
            + struct.pack(">H", length)
            + content
            + b"\xff\xff\xff\xff")

def chunk_ble(packet: bytes, size: int = 20) -> list[bytes]:
    """Split a BLE packet into <=20-byte writes to fff1."""
    return [packet[i:i + size] for i in range(0, len(packet), size)]

def build_wifi_config(ssid: str, password: str) -> list[bytes]:
    """Provision WiFi. NOTE: the pad radio is 2.4 GHz ONLY -- the SSID must be
    your 2.4 GHz network (e.g. AwesoHome_24G), not a 5 GHz one."""
    return chunk_ble(build_ble_config(BLE_MSG_WIFI, ssid, password))

def build_server_config(pi_ip: str, port: str = "8766") -> list[bytes]:
    """Point the device at the Pi. MUST match the Pi's reserved DHCP IP."""
    return chunk_ble(build_ble_config(BLE_MSG_SERVER, pi_ip, str(port)))


# ===========================================================================
# Self-test  --  validates the verified logic against real captured frames
# ===========================================================================
def _selftest() -> int:
    ok = True
    def check(name, cond):
        nonlocal ok
        print(f"  [{'PASS' if cond else 'FAIL'}] {name}")
        ok = ok and cond

    print("Frame envelope + checksum vs CAPTURED frames")
    login = bytes.fromhex("82 0A 01 A6 03 33 20 14 81 30 81 1B".replace(" ", ""))
    dinfo = bytes.fromhex("82 10 01 55 04 33 20 14 81 30 81 05 70 D6 00 00 00 56".replace(" ", ""))

    check("login checksum verifies", xor_checksum(login[:-1]) == login[-1])
    check("device-info checksum verifies", xor_checksum(dinfo[:-1]) == dinfo[-1])

    lf = parse_frame(login)
    df = parse_frame(dinfo)
    check("login frame parses", lf is not None and lf["cmd"] == CMD_LOGIN)
    check("device-info frame parses", df is not None and df["cmd"] == CMD_DEVICE_INFO)

    print("Field extraction")
    check("login SN == 332014813081", parse_login(lf)["sn"] == "332014813081")
    di = parse_device_info(df)
    check("device-info SN == 332014813081", di["sn"] == "332014813081")
    check("firmware == 0570", di["firmware"] == "0570")
    check("device_type == wifi-compact", di["device_type"] == "wifi-compact")

    print("Builders round-trip (re-parse what we build)")
    ack = build_login_ack(0xA6)
    pack = parse_frame(ack)
    check("login ACK is a valid frame", pack is not None and pack["cmd"] == CMD_LOGIN)
    check("login ACK carries 4-byte code", len(pack["payload"]) == 4)
    # Login ACK code should be a current-ish Unix timestamp (> 2024)
    login_epoch = struct.unpack(">I", pack["payload"])[0]
    check("login ACK code is current epoch (> 2024)", login_epoch > 1704067200)

    print("Time Sync ACK format")
    ts_ack = build_time_sync_ack(0x5C)
    ts_frame = parse_frame(ts_ack)
    check("time sync ACK is valid frame", ts_frame is not None and ts_frame["cmd"] == CMD_TIME_SYNC)
    check("time sync ACK payload is 4 bytes (not 6)", len(ts_frame["payload"]) == 4)
    ts_epoch = struct.unpack(">I", ts_frame["payload"])[0]
    check("time sync ACK epoch is current (> 2024)", ts_epoch > 1704067200)
    diack = parse_frame(build_device_info_ack(0x55))
    check("device-info ACK is a valid frame", diack is not None and diack["cmd"] == CMD_DEVICE_INFO)

    print("Sleep Stage (0x4E) ACK")
    ss_ack = build_sleep_stage_ack(0x5F)
    ss_frame = parse_frame(ss_ack)
    check("sleep stage ACK is valid frame", ss_frame is not None and ss_frame["cmd"] == CMD_SLEEP_STAGE)
    check("sleep stage ACK ack=0x00 (response)", ss_frame["ack"] == 0x00)
    check("sleep stage ACK payload is 0x01 (success)", ss_frame["payload"] == b"\x01")
    check("sleep stage ACK total length is 7 bytes", len(ss_ack) == 7)

    print("BLE provisioning length math (computed, not copied)")
    wifi = build_ble_config(BLE_MSG_WIFI, "AwesoHome_24G", "Awesom@2026")
    srv  = build_ble_config(BLE_MSG_SERVER, "192.168.1.14", "8766")
    # length field is bytes [2:4], big-endian
    check("WiFi 0x1F length == 0x0021", wifi[2:4] == b"\x00\x21")
    check("server 0x23 length == 0x0019", srv[2:4] == b"\x00\x19")
    check("WiFi chunks into 2 writes", len(chunk_ble(wifi)) == 2)
    check("server chunks into 2 writes", len(chunk_ble(srv)) == 2)
    check("every chunk <= 20 bytes", all(len(c) <= 20 for c in chunk_ble(wifi) + chunk_ble(srv)))

    print("\nRESULT:", "ALL CHECKS PASSED" if ok else "FAILURES ABOVE")
    return 0 if ok else 1


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        raise SystemExit(_selftest())
    print(__doc__)
