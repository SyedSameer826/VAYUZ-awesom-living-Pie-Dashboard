@echo off
REM Double-click this to run the complete setup (reset-if-needed + scan + static IP + deploy).
REM Must be in the SAME FOLDER as deploy-pi.ps1 and setup-dashboard-pi.sh

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy-pi.ps1"

echo.
echo ============================================
echo Script finished. Press any key to close...
echo ============================================
pause >nul
