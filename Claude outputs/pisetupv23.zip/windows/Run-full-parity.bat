@echo off
REM Double-click to send and run setup-full-parity.sh on .106
REM Must be in the SAME FOLDER as run-full-parity.ps1 and setup-full-parity.sh

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run-full-parity.ps1"

echo.
echo ============================================
echo Script finished. Press any key to close...
echo ============================================
pause >nul
