<#
==============================================================================
 run-full-parity.ps1
 Run this ON YOUR WINDOWS LAPTOP.

 Sends the fully self-contained setup-pi-fresh.sh to .106 and runs it.
 setup-pi-fresh.sh does EVERYTHING: dashboard, camera-wrapper, go2rtc,
 mosquitto, zigbee2mqtt, mqtt bridge, GLK bridge, autossh tunnel, and
 hub heartbeat — all in one script.

 REQUIRES: plink.exe on PATH, setup-pi-fresh.sh in parent folder or same folder.

 *** UPDATED 2026-08-19: Added environment selector (Production / QA).
 *** Passes --prod or --qa flag to setup-pi-fresh.sh so the interactive
 *** 'read' prompt is skipped (stdin is consumed by the 'cat' pipe).
==============================================================================
#>

# ---------------------------- ENVIRONMENT SELECTOR -------------------------
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Awesom Living - Pi Full Parity Setup" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  1) Production  (awesomliving.com)" -ForegroundColor White
Write-Host "  2) QA          (qa.awesomliving.com)" -ForegroundColor White
Write-Host ""
$EnvChoice = Read-Host "  Select environment (1 or 2)"

if ($EnvChoice -eq "2") {
    $DeployEnv = "qa"
    $EnvLabel  = "QA"
    $BackendUrl = "https://qa.awesomliving.com"
} else {
    $DeployEnv = "prod"
    $EnvLabel  = "PRODUCTION"
    $BackendUrl = "https://awesomliving.com"
}

Write-Host ""
Write-Host "  >>> Setting up for: $EnvLabel ($BackendUrl) <<<" -ForegroundColor Yellow
Write-Host ""

# ---------------------------- CONFIG ------------------------------------
$TargetIP    = "192.168.50.106"
$PiUser      = "pi"
$PiPassword  = "1234"

$PlinkPath   = "plink"
$ScriptDir   = $PSScriptRoot
$ParentDir   = Split-Path $ScriptDir -Parent

# setup-pi-fresh.sh lives in parent folder (root of pi-setup-complete/)
$SetupScript = "$ParentDir\setup-pi-fresh.sh"
if (-not (Test-Path $SetupScript)) {
    $SetupScript = "$ScriptDir\setup-pi-fresh.sh"
}
# ---------------------------------------------------------------------------

function Fail($msg) {
    Write-Host "ERROR: $msg" -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

if (-not (Get-Command $PlinkPath -ErrorAction SilentlyContinue)) { Fail "plink not found. Get it from https://www.putty.org/" }
if (-not (Test-Path $SetupScript)) { Fail "setup-pi-fresh.sh not found in $ParentDir or $ScriptDir." }

$resolvedScript = (Resolve-Path -LiteralPath $SetupScript).Path
$scriptName = Split-Path $resolvedScript -Leaf

Write-Host "==> Sending setup-pi-fresh.sh to $TargetIP and running it ($EnvLabel)..." -ForegroundColor Cyan
Write-Host "    This installs: Dashboard, camera-wrapper, go2rtc, Mosquitto," -ForegroundColor Yellow
Write-Host "    Zigbee2MQTT, MQTT bridge, GLK bridge, autossh tunnel, hub heartbeat." -ForegroundColor Yellow
Write-Host "    This will take 15-30 minutes. Do NOT close this window." -ForegroundColor Yellow

# Pre-cache host key
cmd /c "echo y | `"$PlinkPath`" -ssh -pw $PiPassword $PiUser@$TargetIP `"exit`" 2>nul"

# CRITICAL FIX: Pass --prod or --qa flag so setup-pi-fresh.sh skips the
# interactive 'read' prompt. When piped via plink, stdin is consumed by 'cat'
# and 'read' would get EOF -> exit 1, crashing the script.
$remoteCmd = "cat > ~/$scriptName && chmod +x ~/$scriptName && sed -i 's/\r$//' ~/$scriptName && ~/$scriptName --$DeployEnv"
$cmdLine = "type `"$resolvedScript`" | `"$PlinkPath`" -ssh -pw $PiPassword $PiUser@$TargetIP `"$remoteCmd`""
cmd /c $cmdLine

if ($LASTEXITCODE -ne 0) {
    Fail "setup-pi-fresh.sh failed (exit code $LASTEXITCODE). Scroll up to see which step failed."
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Complete Pi Setup Done! ($EnvLabel)" -ForegroundColor Green
Write-Host "  Dashboard: http://${TargetIP}:4000" -ForegroundColor Green
Write-Host "  Backend:   $BackendUrl" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Next steps:" -ForegroundColor Cyan
Write-Host "    1. Open Pi Dashboard: http://${TargetIP}:4000" -ForegroundColor White
Write-Host "    2. Login with your Awesom Living account" -ForegroundColor White
Write-Host "    3. Select the home from the dropdown (first-time only)" -ForegroundColor White
Write-Host "    4. Map your Zigbee devices and cameras" -ForegroundColor White
Read-Host "Press Enter to close"
