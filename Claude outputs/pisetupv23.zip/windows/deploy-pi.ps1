<#
==============================================================================
 deploy-pi.ps1  -  COMPLETE, ALL-IN-ONE SCRIPT (v5 - SSH fallback + gateway fix)
 Run this ON YOUR WINDOWS LAPTOP (same WiFi network as the Pi).

 Based on the proven v3 structure that uses cmd.exe's "type | plink" pattern
 to avoid PowerShell's CRLF and stdin piping issues (lessons #20, #23).

 What it does, in order:
   0. Asks: Production or QA?
   1. Clears stale PuTTY host keys for the Pi subnet (lesson #22).
   2. Checks if $StaticIP is already up (leftover from a previous run). If
      so, copies reset-to-dhcp.sh over and runs it, reverting to DHCP first.
   3. Scans the subnet for the Pi:
      a) nmap vendor match (looks for "Raspberry Pi" MAC)
      b) SSH probe on all alive hosts with pi/<password>
      c) SSH sweep on DHCP range (192.168.50.100-199)
      d) Manual IP entry as last resort
   4. Copies set-static-ip.sh over and runs it to assign a static IP, reboots.
   5. Waits for it to come back up on the new static IP.
   6. Copies setup-pi-fresh.sh over and runs it with --prod or --qa flag
      (COMPLETE setup - dashboard + camera + zigbee + mqtt + GLK + hub heartbeat).

 REQUIRES:
   - nmap on PATH
   - PuTTY's plink.exe on PATH (https://www.putty.org/)
   - set-static-ip.sh, reset-to-dhcp.sh in the SAME FOLDER as this script
   - setup-pi-fresh.sh in the PARENT FOLDER (or same folder)

 v5 changes (2026-09-01):
   - Gateway (192.168.50.1) excluded from candidates (Cudy router has Broadcom
     MAC that nmap misidentifies as Raspberry Pi)
   - SSH validation: every nmap candidate is verified with plink before use
   - SSH fallback: if nmap vendor match fails, tries SSH login on alive hosts
     and then on the full DHCP range (100-199)
   - Manual IP entry: if all automatic detection fails, user can type the IP
   - 10 scan attempts (up from 6) for slow first boot
==============================================================================
#>

# ---------------------------- ENVIRONMENT SELECTOR -------------------------
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Awesom Living - Pi Setup" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  1) Production  (awesomliving.com)" -ForegroundColor White
Write-Host "  2) QA          (qa.awesomliving.com)" -ForegroundColor White
Write-Host ""
$EnvChoice = Read-Host "  Select environment (1 or 2)"

if ($EnvChoice -eq "2") {
    $DeployEnv = "qa"
    $EnvLabel  = "QA"
    $BackendUrl = "https://qa.awesomliving.com"
} else {
    $DeployEnv = "prod"
    $EnvLabel  = "PRODUCTION"
    $BackendUrl = "https://awesomliving.com"
}

Write-Host ""
Write-Host "  >>> Setting up for: $EnvLabel ($BackendUrl) <<<" -ForegroundColor Yellow
Write-Host ""

# ---------------------------- CONFIG ------------------------------------
$Subnet        = "192.168.50.0/24"
$Gateway       = "192.168.50.1"
$StaticIP      = "192.168.50.106"
$ExcludeIPs    = @("192.168.50.50", $Gateway)   # known hub + gateway (router)

$PiUser        = "pi"
$PiPassword    = "1234"

$PlinkPath     = "plink"

$ScriptDir            = $PSScriptRoot
$ParentDir            = Split-Path $ScriptDir -Parent
$SetStaticIpScript    = "$ScriptDir\set-static-ip.sh"
$ResetToDhcpScript    = "$ScriptDir\reset-to-dhcp.sh"

# setup-pi-fresh.sh lives in parent folder (root of pi-setup-complete/)
$SetupScript = "$ParentDir\setup-pi-fresh.sh"
if (-not (Test-Path $SetupScript)) {
    # Fallback: same folder
    $SetupScript = "$ScriptDir\setup-pi-fresh.sh"
}
# ---------------------------------------------------------------------------

function Fail($msg) {
    Write-Host "ERROR: $msg" -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

# Tests SSH login on a host. Returns $true if pi/<password> login succeeds.
function Test-PiSSH {
    param([string]$TestIp)
    $out = cmd /c "echo y | `"$PlinkPath`" -ssh -pw $PiPassword $PiUser@$TestIp `"echo PI_FOUND`" 2>&1"
    return ("$out" -match "PI_FOUND")
}

# Copies a local script to the Pi and runs it with the given arguments.
# Uses cmd.exe's "type | plink" pattern - PowerShell's native piping
# mangles CRLF and stdin in ways that break bash on the Pi (lesson #23).
function Invoke-RemoteScript {
    param(
        [string]$TargetHost,
        [string]$LocalScript,
        [string]$RemoteArgs = ""
    )
    $resolvedScript = (Resolve-Path -LiteralPath $LocalScript -ErrorAction SilentlyContinue).Path
    if (-not $resolvedScript) {
        Fail "Cannot resolve local script path: $LocalScript"
    }
    $scriptName = Split-Path $resolvedScript -Leaf
    Write-Host "    Sending $resolvedScript -> ${TargetHost}:~/$scriptName (via plink)" -ForegroundColor DarkGray

    # Lesson #25: Pre-cache the host key so "type | plink" won't be prompted.
    cmd /c "echo y | `"$PlinkPath`" -ssh -pw $PiPassword $PiUser@$TargetHost `"exit`" 2>nul"

    $remoteCmd = "cat > ~/$scriptName && chmod +x ~/$scriptName && sed -i 's/\r$//' ~/$scriptName && ~/$scriptName $RemoteArgs"
    $cmdLine = "type `"$resolvedScript`" | `"$PlinkPath`" -ssh -pw $PiPassword $PiUser@$TargetHost `"$remoteCmd`""
    cmd /c $cmdLine
    if ($LASTEXITCODE -ne 0) {
        Fail "Failed to send/run $scriptName on ${TargetHost} (exit code $LASTEXITCODE)."
    }
}

# ---- Lesson #22: Clear stale PuTTY host keys ----
Write-Host "Clearing stale SSH host keys for 192.168.50.* ..." -ForegroundColor Gray
$regPath = "HKCU:\Software\SimonTatham\PuTTY\SshHostKeys"
if (Test-Path $regPath) {
    $keys = Get-ItemProperty $regPath
    foreach ($prop in $keys.PSObject.Properties) {
        if ($prop.Name -match "192\.168\.50\.") {
            Remove-ItemProperty -Path $regPath -Name $prop.Name -ErrorAction SilentlyContinue
        }
    }
}

# ---- Sanity checks ----
if (-not (Get-Command nmap -ErrorAction SilentlyContinue)) { Fail "nmap not found on PATH." }
if (-not (Get-Command $PlinkPath -ErrorAction SilentlyContinue)) { Fail "plink not found. Get it from https://www.putty.org/" }
foreach ($f in @($SetStaticIpScript, $ResetToDhcpScript)) {
    if (-not (Test-Path $f)) { Fail "$f not found. It must be in the same folder as this script." }
}
if (-not (Test-Path $SetupScript)) { Fail "setup-pi-fresh.sh not found in $ParentDir or $ScriptDir." }

# ---- Step 0: reset a leftover static-IP Pi back to DHCP, if present ----
Write-Host "==> Checking if $StaticIP is already in use from a previous run..." -ForegroundColor Cyan
if (Test-Connection -ComputerName $StaticIP -Count 1 -Quiet) {
    Write-Host "    $StaticIP is already up - reverting it back to DHCP first..." -ForegroundColor Yellow
    Invoke-RemoteScript -TargetHost $StaticIP -LocalScript $ResetToDhcpScript

    Write-Host "    Reset sent. Waiting for it to go offline..." -ForegroundColor Yellow
    for ($i = 1; $i -le 12; $i++) {
        Start-Sleep -Seconds 5
        if (-not (Test-Connection -ComputerName $StaticIP -Count 1 -Quiet)) { break }
    }
    Write-Host "    Waiting ~20s more for the Pi to fully reboot before scanning..." -ForegroundColor Yellow
    Start-Sleep -Seconds 20
}
else {
    Write-Host "    Nothing at $StaticIP yet - proceeding straight to scan." -ForegroundColor Green
}

# ---- Step 1: Scan the network for the spare Pi ----
Write-Host "==> Scanning $Subnet for Raspberry Pi devices..." -ForegroundColor Cyan
Write-Host "    First boot after a fresh image takes 2-3 minutes." -ForegroundColor DarkGray

$DhcpIp = $null
$scanAttempts = 10

for ($attempt = 1; $attempt -le $scanAttempts; $attempt++) {
    Write-Host "    Scan $attempt/$scanAttempts ..." -ForegroundColor DarkGray
    $nmapOutput = nmap -sn $Subnet 2>&1

    # ---- Method A: nmap vendor identification ("Raspberry Pi" in MAC line) ----
    $currentIp = $null
    $aliveHosts = @()
    foreach ($line in $nmapOutput) {
        if ($line -match "Nmap scan report for ([\d\.]+)") {
            $currentIp = $matches[1]
        }
        elseif ($line -match "Host is up" -and $currentIp) {
            if ($ExcludeIPs -notcontains $currentIp -and $currentIp -ne $StaticIP) {
                $aliveHosts += $currentIp
            }
        }
        elseif ($line -match "Raspberry Pi" -and $currentIp) {
            # Skip excluded IPs (gateway, known hub)
            if ($ExcludeIPs -notcontains $currentIp -and $currentIp -ne $StaticIP) {
                Write-Host "    nmap says $currentIp is a Pi - verifying SSH..." -ForegroundColor Yellow
                if (Test-PiSSH $currentIp) {
                    Write-Host "    SSH verified on $currentIp!" -ForegroundColor Green
                    $DhcpIp = $currentIp
                } else {
                    Write-Host "    SSH failed on $currentIp (false positive, skipping)" -ForegroundColor DarkGray
                }
            }
            $currentIp = $null
        }
    }
    if ($DhcpIp) { break }

    # ---- Method B (from attempt 3): SSH probe on all alive non-excluded hosts ----
    if ($attempt -ge 3 -and $aliveHosts.Count -gt 0) {
        Write-Host "    Trying SSH on $($aliveHosts.Count) alive host(s)..." -ForegroundColor Yellow
        foreach ($tryIp in $aliveHosts) {
            Write-Host "      $tryIp ... " -ForegroundColor DarkGray -NoNewline
            if (Test-PiSSH $tryIp) {
                Write-Host "SSH OK!" -ForegroundColor Green
                $DhcpIp = $tryIp
                break
            } else {
                Write-Host "no" -ForegroundColor DarkGray
            }
        }
        if ($DhcpIp) { break }
    }

    # ---- Method C (from attempt 6): SSH sweep on DHCP range 100-199 ----
    if ($attempt -ge 6) {
        Write-Host "    Sweeping DHCP range 192.168.50.100-199 via SSH..." -ForegroundColor Yellow
        for ($octet = 100; $octet -le 199; $octet++) {
            $tryIp = "192.168.50.$octet"
            if ($ExcludeIPs -contains $tryIp -or $tryIp -eq $StaticIP) { continue }
            # Quick ping first (1s timeout) to avoid slow SSH timeouts
            if (Test-Connection -ComputerName $tryIp -Count 1 -Quiet) {
                Write-Host "      $tryIp alive - testing SSH... " -ForegroundColor DarkGray -NoNewline
                if (Test-PiSSH $tryIp) {
                    Write-Host "SSH OK!" -ForegroundColor Green
                    $DhcpIp = $tryIp
                    break
                } else {
                    Write-Host "no" -ForegroundColor DarkGray
                }
            }
        }
        if ($DhcpIp) { break }
    }

    if ($attempt -lt $scanAttempts) {
        Write-Host "    Not found yet - retrying in 10s..." -ForegroundColor Yellow
        Start-Sleep -Seconds 10
    }
}

# ---- Method D: Manual IP entry ----
if (-not $DhcpIp) {
    Write-Host ""
    Write-Host "    Automatic scan could not find the Pi." -ForegroundColor Red
    Write-Host "    Check Cudy DHCP list: http://192.168.50.1 -> DHCP Client List" -ForegroundColor Yellow
    Write-Host ""
    $manualIp = Read-Host "    Enter Pi IP manually (or press Enter to abort)"
    if ($manualIp -and $manualIp -match "^\d+\.\d+\.\d+\.\d+$") {
        Write-Host "    Testing SSH on $manualIp ..." -ForegroundColor Yellow
        if (Test-PiSSH $manualIp) {
            Write-Host "    SSH OK on $manualIp!" -ForegroundColor Green
            $DhcpIp = $manualIp
        } else {
            Fail "SSH login failed on $manualIp (wrong IP, or Pi not ready yet)."
        }
    } else {
        Fail "No Pi found. Make sure Pi is powered on and connected to AwesomLiving_P1 WiFi."
    }
}

Write-Host "==> Found Pi at $DhcpIp" -ForegroundColor Green

# ---- Step 2: Set a static IP on the Pi ----
Write-Host "==> Configuring static IP $StaticIP on the Pi (currently at $DhcpIp)..." -ForegroundColor Cyan
Invoke-RemoteScript -TargetHost $DhcpIp -LocalScript $SetStaticIpScript -RemoteArgs "$PiPassword $StaticIP $Gateway 8.8.8.8,8.8.4.4 24"
Write-Host "==> Static IP command sent, Pi is rebooting..." -ForegroundColor Green

# ---- Step 3: Wait for the Pi to come back at the new static IP ----
Write-Host "==> Waiting for $StaticIP to come back online..." -ForegroundColor Cyan
$maxTries = 30
$upAt = $null
for ($i = 1; $i -le $maxTries; $i++) {
    Start-Sleep -Seconds 5
    if (Test-Connection -ComputerName $StaticIP -Count 1 -Quiet) { $upAt = $StaticIP; break }
    Write-Host "    still waiting... ($i/$maxTries)"
}
if (-not $upAt) {
    Fail "Pi did not come back up at $StaticIP after $($maxTries * 5) seconds."
}
Write-Host "==> Pi is back online at $StaticIP" -ForegroundColor Green
Start-Sleep -Seconds 5

# ---- Step 4: Copy and run the COMPLETE setup script ----
Write-Host "==> Copying and running setup-pi-fresh.sh on the Pi ($EnvLabel mode)..." -ForegroundColor Cyan
Write-Host "    This installs: Dashboard, camera-wrapper, go2rtc, Mosquitto," -ForegroundColor Yellow
Write-Host "    Zigbee2MQTT, MQTT bridge, GLK bridge, autossh tunnel, hub heartbeat." -ForegroundColor Yellow
Write-Host "    This will take 15-30 minutes. Do NOT close this window." -ForegroundColor Yellow
Invoke-RemoteScript -TargetHost $StaticIP -LocalScript $SetupScript -RemoteArgs "--$DeployEnv"

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Complete Pi Setup Done! ($EnvLabel)" -ForegroundColor Green
Write-Host "  Pi is at: $StaticIP" -ForegroundColor Green
Write-Host "  Dashboard: http://${StaticIP}:4000" -ForegroundColor Green
Write-Host "  Backend:   $BackendUrl" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Next steps:" -ForegroundColor Cyan
Write-Host "    1. Open Pi Dashboard: http://${StaticIP}:4000" -ForegroundColor White
Write-Host "    2. Login with your Awesom Living account" -ForegroundColor White
Write-Host "    3. Select the home from the dropdown (first-time only)" -ForegroundColor White
Write-Host "    4. Map your Zigbee devices and cameras" -ForegroundColor White
Read-Host "Press Enter to close"
