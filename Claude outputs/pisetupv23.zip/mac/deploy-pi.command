#!/usr/bin/env bash
# ==============================================================================
# deploy-pi.command — Mac orchestrator (v6 - Gateway exclusion fix)
# Double-click in Finder to run. Equivalent of windows/deploy-pi.ps1.
#
# What it does:
#   0. Asks: Production or QA?
#   1. Checks if .106 already has a Pi → reset to DHCP if so
#   2. Scans the subnet for a fresh Raspberry Pi (excludes .50)
#   3. Sets static IP 192.168.50.106
#   4. Waits for reboot, then deploys the FULL setup (dashboard + camera +
#      zigbee + mqtt + GLK + hub heartbeat) via setup-pi-fresh.sh
#
# REQUIRES: sshpass (auto-installs via brew if missing), nmap (optional)
#
# *** UPDATED 2026-08-18: Merged QA/Prod into single script with env selector.
# ==============================================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PARENT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

PI_USER="pi"
PI_PASS="1234"
TARGET_IP="192.168.50.106"
GATEWAY="192.168.50.1"
SAFE_IP="192.168.50.50"   # Production hub — NEVER touch

# The setup script lives one level up (root of pi-setup-complete/)
SETUP_SCRIPT="${PARENT_DIR}/setup-pi-fresh.sh"
if [ ! -f "$SETUP_SCRIPT" ]; then
    # Also check same folder as fallback
    SETUP_SCRIPT="${SCRIPT_DIR}/setup-pi-fresh.sh"
fi

# ── Environment selector ──
echo ""
echo "============================================"
echo "  Select Environment"
echo "============================================"
echo "  1) Production  (awesomliving.com)"
echo "  2) QA          (qa.awesomliving.com)"
echo ""
read -rp "  Enter 1 or 2: " ENV_CHOICE
case "$ENV_CHOICE" in
  2|qa|QA)
    DEPLOY_ENV="qa"
    ENV_LABEL="QA"
    BACKEND_URL="https://qa.awesomliving.com"
    ;;
  *)
    DEPLOY_ENV="prod"
    ENV_LABEL="PRODUCTION"
    BACKEND_URL="https://awesomliving.com"
    ;;
esac

echo ""
echo "  >>> Setting up for: ${ENV_LABEL} (${BACKEND_URL}) <<<"
echo ""

# ── Helper: SSH into the Pi ──
ssh_pi() {
    local ip="$1"; shift
    sshpass -p "$PI_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5 "$PI_USER@$ip" "$@"
}

# ── Helper: SCP a file to the Pi ──
scp_pi() {
    local ip="$1"; local src="$2"; local dst="$3"
    sshpass -p "$PI_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$src" "$PI_USER@$ip:$dst"
}

# Check sshpass is installed
if ! command -v sshpass &>/dev/null; then
    echo "Installing sshpass (needed for automated SSH)..."
    brew install hudochenkov/sshpass/sshpass 2>/dev/null || {
        echo "ERROR: Please install sshpass: brew install hudochenkov/sshpass/sshpass"
        exit 1
    }
fi

# Check setup script exists
if [ ! -f "$SETUP_SCRIPT" ]; then
    echo "ERROR: setup-pi-fresh.sh not found."
    echo "  Looked in: ${PARENT_DIR}/ and ${SCRIPT_DIR}/"
    exit 1
fi

echo ""
echo "============================================"
echo "  Awesom Living - Complete Pi Setup (${ENV_LABEL})"
echo "  Backend: ${BACKEND_URL}"
echo "============================================"

# ── Step 0: Check if .106 already has a Pi from a previous run ──
echo ""
echo "[Step 0] Checking if $TARGET_IP already has a Pi from a previous run..."
if ssh_pi "$TARGET_IP" "echo ALIVE" 2>/dev/null | grep -q "ALIVE"; then
    echo "  Found a Pi at $TARGET_IP. Resetting to DHCP first..."
    scp_pi "$TARGET_IP" "$SCRIPT_DIR/reset-to-dhcp.sh" "/tmp/reset-to-dhcp.sh"
    ssh_pi "$TARGET_IP" "chmod +x /tmp/reset-to-dhcp.sh && /tmp/reset-to-dhcp.sh" 2>/dev/null || true
    echo "  Waiting 20s for Pi to reboot..."
    sleep 20
else
    echo "  Nothing at $TARGET_IP yet — proceeding straight to scan."
fi

# ── Step 1: Scan for the Pi ──
echo ""
echo "[Step 1] Scanning network for a fresh Pi (up to 6 attempts)..."

PI_IP=""
for attempt in $(seq 1 6); do
    echo "  Attempt $attempt of 6..."
    if command -v nmap &>/dev/null; then
        SCAN=$(nmap -sn 192.168.50.0/24 2>&1)
    else
        SCAN=$(arp -a 2>&1)
    fi

    # Look for Raspberry Pi in scan output
    while IFS= read -r ip; do
        if [ "$ip" != "$SAFE_IP" ] && [ "$ip" != "$TARGET_IP" ] && [ "$ip" != "$GATEWAY" ] && [ -n "$ip" ]; then
            PI_IP="$ip"
            break
        fi
    done < <(echo "$SCAN" | grep -i "raspberry" | grep -oE '192\.168\.50\.[0-9]+')

    if [ -n "$PI_IP" ]; then
        echo "  Found Pi at: $PI_IP"
        break
    fi

    if [ "$attempt" -lt 6 ]; then
        echo "  No Pi found yet. Retrying in 10s..."
        sleep 10
    fi
done

if [ -z "$PI_IP" ]; then
    echo "ERROR: Could not find a Raspberry Pi on the network after 6 attempts."
    echo "Make sure the Pi is powered on and connected to the same WiFi."
    exit 1
fi

# ── Step 2: Set static IP ──
echo ""
echo "[Step 2] Setting static IP to $TARGET_IP on Pi at $PI_IP..."
scp_pi "$PI_IP" "$SCRIPT_DIR/set-static-ip.sh" "/tmp/set-static-ip.sh"
ssh_pi "$PI_IP" "chmod +x /tmp/set-static-ip.sh && /tmp/set-static-ip.sh '$TARGET_IP' '$GATEWAY'" 2>/dev/null || true

echo "  Static IP script sent. Waiting 30s for reboot..."
sleep 30

# Wait for it to come back
echo "  Checking if Pi is up at $TARGET_IP..."
for i in $(seq 1 20); do
    if ssh_pi "$TARGET_IP" "echo ALIVE" 2>/dev/null | grep -q "ALIVE"; then
        echo "  Pi is reachable at $TARGET_IP"
        break
    fi
    if [ "$i" -eq 20 ]; then
        echo "ERROR: Pi did not come back up at $TARGET_IP after 100 seconds."
        exit 1
    fi
    echo "    still waiting... ($i/20)"
    sleep 5
done

# ── Step 3: Deploy COMPLETE setup (dashboard + all services) ──
echo ""
echo "[Step 3] Deploying complete setup to $TARGET_IP (${ENV_LABEL} mode)..."
echo "  This installs: Dashboard, camera-wrapper, go2rtc, Mosquitto,"
echo "  Zigbee2MQTT, MQTT bridge, GLK bridge, autossh tunnel, hub heartbeat."
echo "  This will take 15-30 minutes. Do NOT close this window."
echo ""
scp_pi "$TARGET_IP" "$SETUP_SCRIPT" "/home/${PI_USER}/setup-pi-fresh.sh"
ssh_pi "$TARGET_IP" "chmod +x /home/${PI_USER}/setup-pi-fresh.sh && /home/${PI_USER}/setup-pi-fresh.sh --${DEPLOY_ENV}"

echo ""
echo "============================================"
echo "  Complete Pi Setup Done! (${ENV_LABEL})"
echo "  Pi is at: $TARGET_IP"
echo "  Dashboard: http://${TARGET_IP}:4000"
echo "  Backend:   ${BACKEND_URL}"
echo "============================================"
echo ""
echo "  Next steps:"
echo "    1. Open Pi Dashboard: http://${TARGET_IP}:4000"
echo "    2. Login with your Awesom Living account"
echo "    3. Select the home from the dropdown (first-time only)"
echo "    4. Map your Zigbee devices and cameras"
