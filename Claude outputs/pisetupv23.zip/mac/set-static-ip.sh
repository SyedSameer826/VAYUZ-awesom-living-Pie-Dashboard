#!/bin/bash
# set-static-ip.sh
# Usage: ./set-static-ip.sh <pi_password> <static_ip> <gateway> <dns> <subnet_mask>
# Sets a static IP on the Pi's currently-active network connection and reboots.

set -e

SUDO_PASS="$1"
STATIC_IP="$2"
GATEWAY="$3"
DNS="$4"
MASK="$5"

if [[ -z "$STATIC_IP" || -z "$GATEWAY" || -z "$DNS" || -z "$MASK" ]]; then
    echo "Usage: $0 <pi_password> <static_ip> <gateway> <dns> <subnet_mask>"
    exit 1
fi

echo "$SUDO_PASS" | sudo -S -v -p '' 2>/dev/null
sudo_run() {
    sudo "$@"
}

if command -v nmcli >/dev/null 2>&1; then
    CONN=$(nmcli -t -f NAME,DEVICE connection show --active | grep -v '^lo:' | head -n1 | cut -d: -f1)
    echo "Using nmcli connection: $CONN"
    sudo_run nmcli connection modify "$CONN" ipv4.addresses "${STATIC_IP}/${MASK}" ipv4.gateway "$GATEWAY" ipv4.dns "$DNS" ipv4.method manual
    echo "Static IP config saved. Skipping 'nmcli connection up' (can hang) - the reboot below will apply it."
else
    echo "nmcli not found, using dhcpcd.conf fallback"
    IFACE=$(ip route | awk '/default/ {print $5; exit}')
    {
        echo ""
        echo "interface $IFACE"
        echo "static ip_address=${STATIC_IP}/${MASK}"
        echo "static routers=${GATEWAY}"
        echo "static domain_name_servers=${DNS}"
    } > /tmp/dhcpcd-append.txt
    sudo_run bash -c "cat /tmp/dhcpcd-append.txt >> /etc/dhcpcd.conf"
    rm -f /tmp/dhcpcd-append.txt
fi

echo "Static IP configured, rebooting..."
sudo_run reboot
