#!/bin/bash
# reset-to-dhcp.sh
# Reverts the Pi's currently-active WiFi connection back to DHCP and reboots.
# Lesson #7: Do NOT use 'nmcli connection up' — it hangs. Reboot instead.

set -e

# Authenticate sudo
if ! sudo -n true 2>/dev/null; then
    echo "1234" | sudo -S -v -p '' 2>/dev/null
fi

# Find the active WiFi connection name
CONN=$(nmcli -t -f NAME,TYPE con show --active | grep wireless | head -1 | cut -d: -f1)
if [ -z "$CONN" ]; then
    # If no active connection, try to find any WiFi connection
    CONN=$(nmcli -t -f NAME,TYPE con show | grep wireless | head -1 | cut -d: -f1)
fi

if [ -z "$CONN" ]; then
    echo "ERROR: No WiFi connection found."
    exit 1
fi

echo "Resetting connection '$CONN' to DHCP..."

sudo nmcli con mod "$CONN" ipv4.method auto \
    ipv4.addresses "" \
    ipv4.gateway "" \
    ipv4.dns ""

echo "DHCP restored. Rebooting..."
sudo reboot
