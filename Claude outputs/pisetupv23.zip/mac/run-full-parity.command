#!/usr/bin/env bash
# ==============================================================================
# run-full-parity.command — Mac orchestrator (v8 - uses setup-pi-fresh.sh)
# Double-click in Finder to run.
# 1. Scans for Pi on the network
# 2. Sets static IP to .106 (no reboot — applies live)
# 3. Runs setup-pi-fresh.sh at .106
#
# NOTE: setup-pi-fresh.sh now does EVERYTHING (dashboard + camera + zigbee +
#       mqtt + GLK + hub heartbeat). This script is equivalent to deploy-pi.command.
#       Kept for backward compatibility.
#
# REQUIRES: sshpass, setup-pi-fresh.sh in parent folder or same folder.
#
# *** UPDATED 2026-08-19: Added environment selector (Production / QA).
# *** Passes --prod or --qa flag to setup-pi-fresh.sh.
# ==============================================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PARENT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

PI_USER="pi"
PI_PASS="1234"
STATIC_IP="192.168.50.106"
GATEWAY="192.168.50.1"
SUBNET="192.168.50"
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5"
SCAN_SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=2"

# The setup script lives one level up (root of pi-setup-complete/)
SETUP_SCRIPT="${PARENT_DIR}/setup-pi-fresh.sh"
if [ ! -f "$SETUP_SCRIPT" ]; then
    SETUP_SCRIPT="${SCRIPT_DIR}/setup-pi-fresh.sh"
fi

# ── Environment selector ──
echo ""
echo "============================================"
echo "  Select Environment"
echo "============================================"
echo "  1) Production  (awesomliving.com)"
echo "  2) QA          (qa.awesomliving.com)"
echo ""
read -rp "  Enter 1 or 2: " ENV_CHOICE
case "$ENV_CHOICE" in
  2|qa|QA)
    DEPLOY_ENV="qa"
    ENV_LABEL="QA"
    BACKEND_URL="https://qa.awesomliving.com"
    ;;
  *)
    DEPLOY_ENV="prod"
    ENV_LABEL="PRODUCTION"
    BACKEND_URL="https://awesomliving.com"
    ;;
esac

echo ""
echo "  >>> Setting up for: ${ENV_LABEL} (${BACKEND_URL}) <<<"

echo "============================================"
echo "  Awesom Living - Complete Pi Setup (${ENV_LABEL})"
echo "  (Scan → Static IP → Full Setup)"
echo "============================================"
echo ""

# ── 0. Install sshpass if missing ──
if ! command -v sshpass &>/dev/null; then
    echo "[0] Installing sshpass..."
    brew install hudochenkov/sshpass/sshpass 2>/dev/null || {
        echo "ERROR: Please install sshpass: brew install hudochenkov/sshpass/sshpass"
        exit 1
    }
fi

# ── 1. Check required files ──
if [ ! -f "$SETUP_SCRIPT" ]; then
    echo "ERROR: setup-pi-fresh.sh not found."
    echo "  Looked in: ${PARENT_DIR}/ and ${SCRIPT_DIR}/"
    exit 1
fi

# ── 2. Scan the network for Raspberry Pi ──
echo "[1] Scanning ${SUBNET}.0/24 for Raspberry Pi..."
echo ""

PI_IP=""

# First check if Pi is already at the static IP
if sshpass -p "$PI_PASS" ssh $SSH_OPTS "$PI_USER@$STATIC_IP" "echo ALIVE" 2>/dev/null | grep -q "ALIVE"; then
    echo "  Pi found at static IP $STATIC_IP (already configured)"
    PI_IP="$STATIC_IP"
fi

if [ -z "$PI_IP" ]; then
    echo "  Pi not at $STATIC_IP. Scanning network..."

    # Ping sweep to populate ARP table
    for i in $(seq 1 254); do
        ping -c 1 -W 1 "${SUBNET}.${i}" &>/dev/null &
    done
    wait 2>/dev/null
    sleep 2

    # Temp file for parallel SSH results
    SCAN_RESULT=$(mktemp /tmp/pi-scan.XXXXXX)

    # Step 1: Try Pi MAC prefixes from ARP first (fastest)
    echo "  Checking known Pi MAC addresses..."
    while IFS= read -r line; do
        ip=$(echo "$line" | grep -oE "${SUBNET}\.[0-9]+")
        if [ -n "$ip" ] && [ "$ip" != "$GATEWAY" ]; then
            if sshpass -p "$PI_PASS" ssh $SCAN_SSH_OPTS "$PI_USER@$ip" "echo ALIVE" 2>/dev/null | grep -q "ALIVE"; then
                PI_IP="$ip"
                echo "  Found Raspberry Pi at: $ip (MAC match)"
                break
            fi
        fi
    done <<< "$(arp -a | grep -i -E 'raspberry|b8:27:eb|dc:a6:32|e4:5f:01|2c:cf:67|d8:3a:dd|28:cd:c1' || true)"

    # Step 2: Try ALL hosts discovered by ARP (parallel, 10 at a time)
    if [ -z "$PI_IP" ]; then
        echo "  MAC lookup missed. Trying all discovered hosts in parallel..."
        ARP_IPS=$(arp -a | grep -oE "${SUBNET}\.[0-9]+" | grep -v -E "\.1$|\.255$" | sort -t. -k4 -n | uniq || true)

        for ip in $ARP_IPS; do
            [ "$ip" = "$GATEWAY" ] && continue
            [ "$ip" = "$STATIC_IP" ] && continue
            (
                if sshpass -p "$PI_PASS" ssh $SCAN_SSH_OPTS "$PI_USER@$ip" "echo ALIVE" 2>/dev/null | grep -q "ALIVE"; then
                    echo "$ip" >> "$SCAN_RESULT"
                fi
            ) &
        done
        wait 2>/dev/null

        if [ -s "$SCAN_RESULT" ]; then
            PI_IP=$(head -n1 "$SCAN_RESULT")
            echo "  Found Raspberry Pi at: $PI_IP (ARP discovery)"
        fi
    fi

    # Step 3: Parallel SSH sweep of DHCP range (batches of 20)
    if [ -z "$PI_IP" ]; then
        echo "  ARP missed. Scanning DHCP range in parallel..."
        > "$SCAN_RESULT"
        BATCH=0
        for i in $(seq 2 254); do
            ip="${SUBNET}.${i}"
            [ "$ip" = "$GATEWAY" ] && continue
            [ "$ip" = "$STATIC_IP" ] && continue
            (
                if sshpass -p "$PI_PASS" ssh $SCAN_SSH_OPTS "$PI_USER@$ip" "echo ALIVE" 2>/dev/null | grep -q "ALIVE"; then
                    echo "$ip" >> "$SCAN_RESULT"
                fi
            ) &
            BATCH=$((BATCH + 1))
            if [ $BATCH -ge 20 ]; then
                wait 2>/dev/null
                BATCH=0
                if [ -s "$SCAN_RESULT" ]; then
                    PI_IP=$(head -n1 "$SCAN_RESULT")
                    echo "  Found Raspberry Pi at: $PI_IP"
                    break
                fi
                echo "  Scanned up to ${SUBNET}.${i}..."
            fi
        done
        wait 2>/dev/null

        if [ -z "$PI_IP" ] && [ -s "$SCAN_RESULT" ]; then
            PI_IP=$(head -n1 "$SCAN_RESULT")
            echo "  Found Raspberry Pi at: $PI_IP"
        fi
    fi

    rm -f "$SCAN_RESULT" 2>/dev/null

    # Last resort: ask user
    if [ -z "$PI_IP" ]; then
        echo ""
        echo "  Could not auto-detect Pi on the network."
        read -p "  Enter the Pi's current IP manually (or Ctrl+C to abort): " PI_IP
        if [ -z "$PI_IP" ]; then
            echo "ERROR: No IP provided."
            exit 1
        fi
        if ! sshpass -p "$PI_PASS" ssh $SSH_OPTS "$PI_USER@$PI_IP" "echo ALIVE" 2>/dev/null | grep -q "ALIVE"; then
            echo "ERROR: Cannot reach Pi at $PI_IP"
            exit 1
        fi
    fi
fi

echo ""
echo "  Pi detected at: $PI_IP"
echo ""

# ── 3. Set static IP FIRST (if not already .106) ──
if [ "$PI_IP" != "$STATIC_IP" ]; then
    echo "[2] Setting static IP to $STATIC_IP (currently $PI_IP)..."
    echo ""

    sshpass -p "$PI_PASS" ssh $SSH_OPTS "$PI_USER@$PI_IP" bash -s "$STATIC_IP" "$GATEWAY" "$PI_PASS" <<'STATIC_EOF'
#!/bin/bash
set -e
TARGET_IP="$1"
GATEWAY="$2"
SUDO_PASS="$3"

echo "$SUDO_PASS" | sudo -S -v -p '' 2>/dev/null

echo "  Detecting network configuration method..."

if command -v nmcli &>/dev/null; then
    CONN=$(nmcli -t -f NAME,DEVICE connection show --active | grep -v '^lo:' | head -n1 | cut -d: -f1)

    if [ -n "$CONN" ]; then
        echo "  Using NetworkManager — connection: '$CONN'"
        echo "  Setting IP to $TARGET_IP..."

        sudo nmcli connection modify "$CONN" \
            ipv4.addresses "$TARGET_IP/24" \
            ipv4.gateway "$GATEWAY" \
            ipv4.dns "8.8.8.8,8.8.4.4" \
            ipv4.method manual

        echo "  Config saved. Rebooting to apply..."
        sudo reboot
    else
        echo "  ERROR: No active connection found."
        exit 1
    fi
elif [ -f /etc/dhcpcd.conf ]; then
    IFACE=$(ip route | awk '/default/ {print $5; exit}')
    [ -z "$IFACE" ] && IFACE="wlan0"
    echo "  Using dhcpcd — interface: $IFACE"

    sudo sed -i "/^interface $IFACE/,/^$/d" /etc/dhcpcd.conf 2>/dev/null || true
    {
        echo ""
        echo "interface $IFACE"
        echo "static ip_address=$TARGET_IP/24"
        echo "static routers=$GATEWAY"
        echo "static domain_name_servers=8.8.8.8 8.8.4.4"
    } | sudo tee -a /etc/dhcpcd.conf > /dev/null

    echo "  Config saved. Rebooting to apply..."
    sudo reboot
else
    echo "  ERROR: No supported network manager found."
    exit 1
fi
STATIC_EOF

    echo ""
    echo "  Pi is rebooting. Waiting for it at $STATIC_IP..."
    sleep 15

    RETRY=0
    MAX_RETRIES=24
    PI_IP=""
    while [ $RETRY -lt $MAX_RETRIES ]; do
        RETRY=$((RETRY + 1))
        if sshpass -p "$PI_PASS" ssh $SSH_OPTS "$PI_USER@$STATIC_IP" "echo ALIVE" 2>/dev/null | grep -q "ALIVE"; then
            echo "  Pi is online at $STATIC_IP!"
            PI_IP="$STATIC_IP"
            break
        fi
        echo "  Attempt $RETRY/$MAX_RETRIES..."
        sleep 5
    done

    if [ -z "$PI_IP" ]; then
        echo ""
        echo "  ERROR: Pi did not come back at $STATIC_IP after reboot."
        echo "  Try: ssh pi@<old_ip> to check, or power cycle the Pi."
        exit 1
    fi
else
    echo "[2] Pi already at $STATIC_IP — verifying config is persisted..."

    NEEDS_FIX=$(sshpass -p "$PI_PASS" ssh $SSH_OPTS "$PI_USER@$STATIC_IP" bash -s "$STATIC_IP" "$GATEWAY" <<'VERIFY_EOF'
#!/bin/bash
TARGET_IP="$1"
GATEWAY="$2"
if command -v nmcli &>/dev/null; then
    CONN=$(nmcli -t -f NAME,DEVICE connection show --active | grep -v '^lo:' | head -n1 | cut -d: -f1)
    METHOD=$(nmcli -t -f ipv4.method connection show "$CONN" 2>/dev/null | cut -d: -f2)
    if [ "$METHOD" = "manual" ]; then
        echo "OK"
    else
        echo "FIX"
    fi
else
    echo "OK"
fi
VERIFY_EOF
    )

    if [ "$NEEDS_FIX" = "FIX" ]; then
        echo "  Static IP not persisted (still DHCP). Saving config now..."
        sshpass -p "$PI_PASS" ssh $SSH_OPTS "$PI_USER@$STATIC_IP" bash -s "$STATIC_IP" "$GATEWAY" "$PI_PASS" <<'FIX_EOF'
#!/bin/bash
set -e
TARGET_IP="$1"
GATEWAY="$2"
SUDO_PASS="$3"
echo "$SUDO_PASS" | sudo -S -v -p '' 2>/dev/null
CONN=$(nmcli -t -f NAME,DEVICE connection show --active | grep -v '^lo:' | head -n1 | cut -d: -f1)
echo "  Saving static config on connection: '$CONN'"
sudo nmcli connection modify "$CONN" \
    ipv4.addresses "$TARGET_IP/24" \
    ipv4.gateway "$GATEWAY" \
    ipv4.dns "8.8.8.8,8.8.4.4" \
    ipv4.method manual
echo "  Config saved. Rebooting to apply..."
sudo reboot
FIX_EOF

        echo ""
        echo "  Pi is rebooting to apply static config. Waiting..."
        sleep 15

        RETRY=0
        MAX_RETRIES=24
        while [ $RETRY -lt $MAX_RETRIES ]; do
            RETRY=$((RETRY + 1))
            if sshpass -p "$PI_PASS" ssh $SSH_OPTS "$PI_USER@$STATIC_IP" "echo ALIVE" 2>/dev/null | grep -q "ALIVE"; then
                echo "  Pi is online at $STATIC_IP!"
                break
            fi
            echo "  Attempt $RETRY/$MAX_RETRIES..."
            sleep 5
        done

        if [ $RETRY -eq $MAX_RETRIES ]; then
            echo "  ERROR: Pi did not come back at $STATIC_IP after reboot."
            exit 1
        fi
    else
        echo "  Static IP config is already persisted. Good to go."
    fi
fi

echo ""

# ── 4. Copy and run setup-pi-fresh.sh (COMPLETE setup) ──
echo "[3] Copying setup-pi-fresh.sh to Pi at $PI_IP..."
sshpass -p "$PI_PASS" scp $SSH_OPTS \
    "$SETUP_SCRIPT" "$PI_USER@$PI_IP:/home/${PI_USER}/setup-pi-fresh.sh"

echo "[4] Running setup-pi-fresh.sh (${ENV_LABEL} mode, 15-30 minutes)..."
echo "    Installing: dashboard, camera-wrapper, go2rtc, mosquitto, zigbee2mqtt,"
echo "    mqtt bridge, GLK bridge, autossh tunnel, hub heartbeat"
echo ""
sshpass -p "$PI_PASS" ssh $SSH_OPTS \
    "$PI_USER@$PI_IP" \
    "export DEBIAN_FRONTEND=noninteractive CI=true npm_config_progress=false; chmod +x /home/${PI_USER}/setup-pi-fresh.sh && /home/${PI_USER}/setup-pi-fresh.sh --${DEPLOY_ENV}"

echo ""
echo "============================================"
echo "  Complete Pi Setup Done! (${ENV_LABEL})"
echo "  Pi hub at: $PI_IP"
echo "  Dashboard: http://${PI_IP}:4000"
echo "  Backend:   ${BACKEND_URL}"
echo "============================================"
echo ""
echo "  Next steps:"
echo "    1. Open Pi Dashboard: http://${PI_IP}:4000"
echo "    2. Login with your Awesom Living account"
echo "    3. Select the home from the dropdown (first-time only)"
echo "    4. Map your Zigbee devices and cameras"
