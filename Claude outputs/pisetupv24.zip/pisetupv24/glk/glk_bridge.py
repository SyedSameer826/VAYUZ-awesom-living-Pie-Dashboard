#!/usr/bin/env python3
"""
glk_bridge.py — TCP bridge for the GLK AI Smart Sleep Monitor.

Listens on TCP port 8766. When a GLK device connects (after BLE provisioning),
it handles the full handshake (login -> time sync -> device info) and then
receives ~1 Hz realtime vitals, forwarding them to the Awesom Living backend.

All fixes from testing:
  - Hex dump of every TCP read for debugging
  - TCP_NODELAY to prevent Nagle buffering on small ACK frames
  - Time sync: 4-byte epoch ACK (fixes the 7x loop caused by 6-byte BCD)
  - Compact device info: accepts 18-byte WiFi frame (not 53-byte 4G)
  - Sleep stage (0x4E) forwarding
  - Emergency (0x0D) forwarding
  - time_sync_count tracking per connection
  - Configurable log level, time format debug knob

Debug env vars:
    GLK_TIME_FORMAT=epoch|bcd   — switch Time Sync ACK format (default: epoch)
    GLK_SKIP_TIME_ACK=1         — don't reply to Time Sync at all (test only)
    GLK_LOG_LEVEL=DEBUG         — show extra detail
"""
from __future__ import annotations
import asyncio, json, logging, os, signal, socket, struct, sys, time
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from urllib.error import URLError

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from glk_protocol import (
    FRAME_START, CMD_LOGIN, CMD_TIME_SYNC, CMD_DEVICE_INFO,
    CMD_REALTIME, CMD_SLEEP_STAGE, CMD_EMERGENCY,
    parse_frame, parse_login, parse_device_info,
    build_login_ack, build_device_info_ack,
    build_time_sync_ack, build_time_sync_ack_bcd,
    build_frame, sn_decode,
)

# ── Configuration ──
LISTEN_PORT = int(os.environ.get("GLK_BRIDGE_PORT", "8766"))
LOCAL_BACKEND_URL = os.environ.get("GLK_BACKEND_URL", "http://localhost:4000")
if not LOCAL_BACKEND_URL.endswith("/api/glk/vitals"):
    LOCAL_BACKEND_URL = LOCAL_BACKEND_URL.rstrip("/") + "/api/glk/vitals"
REMOTE_BACKEND_URL = os.environ.get("REMOTE_BACKEND_URL", "")
if REMOTE_BACKEND_URL and not REMOTE_BACKEND_URL.endswith("/api/health"):
    REMOTE_BACKEND_URL = REMOTE_BACKEND_URL.rstrip("/") + "/api/health"
BACKEND_URL = LOCAL_BACKEND_URL
SECRET_KEY = os.environ.get("HUB_SECRET_KEY", "jwt_secret_of_awesomliving_app")
FORWARD_INTERVAL = float(os.environ.get("GLK_FORWARD_INTERVAL", "5"))
IDLE_TIMEOUT = float(os.environ.get("GLK_IDLE_TIMEOUT", "600"))
TIME_FORMAT = os.environ.get("GLK_TIME_FORMAT", "epoch").lower()
SKIP_TIME_ACK = os.environ.get("GLK_SKIP_TIME_ACK", "0") == "1"
LOG_LEVEL = os.environ.get("GLK_LOG_LEVEL", "INFO").upper()

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s [glk-bridge] %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("glk-bridge")

CMD_NAMES = {CMD_LOGIN: "LOGIN", CMD_TIME_SYNC: "TIME_SYNC",
             CMD_DEVICE_INFO: "DEVICE_INFO", CMD_REALTIME: "REALTIME",
             CMD_SLEEP_STAGE: "SLEEP_STAGE", CMD_EMERGENCY: "EMERGENCY"}
STATUS_MAP = {0: "initializing", 1: "in_bed", 2: "apnea_suspected",
              3: "snoring", 4: "out_of_bed", 5: "life_abnormality",
              6: "light_sleep"}

def cmd_name(cmd): return CMD_NAMES.get(cmd, f"0x{cmd:02X}")

def get_time_sync_ack(seq):
    if TIME_FORMAT == "bcd":
        ack = build_time_sync_ack_bcd(seq)
        log.warning("  Time Sync ACK (BCD/6-byte — DEBUG ONLY): %s", ack.hex())
        return ack
    ack = build_time_sync_ack(seq)
    log.info("  Time Sync ACK (epoch/4-byte): %s", ack.hex())
    return ack

def parse_realtime(frame):
    p = frame["payload"]
    if len(p) < 11: return {}
    # Corrected byte layout (Aug 2026):
    # p[0:2]  = protocol markers (constant 0x6A, 0x8A) — NOT vitals
    # p[2:4]  = 16-bit BE second counter — NOT status/movement
    # p[4]    = heart rate (bpm, 0 = no contact / out of bed)
    # p[5]    = respiration rate (brpm, 0 = no contact / apnea)
    # p[6]    = status code (0-5 per STATUS_MAP)
    # p[7]    = battery level (percentage, often 100)
    # p[8]    = reserved (usually 0)
    # p[9]    = signal quality (usually 100)
    # p[10]   = body movement intensity (0-255)
    sc = p[6]
    IN_BED_STATUSES = {1, 2, 3, 5, 6}  # everything except 0 (init) and 4 (out_of_bed)
    return {
        "heart_rate": p[4] if p[4] != 0xFF else None,
        "respiration_rate": p[5] if p[5] != 0xFF else None,
        "status_code": sc, "status": STATUS_MAP.get(sc, f"unknown_{sc}"),
        "in_bed": sc in IN_BED_STATUSES, "out_of_bed": sc == 4,
        "apnea_suspected": sc == 2, "snoring": sc == 3,
        "body_movement": p[10] if len(p) > 10 else 0,
        "battery_level": p[7] if len(p) > 7 else None,
        "life_abnormality": sc == 5,
        "timer_counter": (p[2] << 8) | p[3],
    }

def forward_to_backend(sn, data):
    payload = json.dumps({"serial_number": sn, "secret_key": SECRET_KEY,
                          "data": data, "timestamp": datetime.now(timezone.utc).isoformat()}).encode("utf-8")
    ok = False
    req = Request(LOCAL_BACKEND_URL, data=payload,
                  headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urlopen(req, timeout=5) as resp: ok = 200 <= resp.status < 300
    except (URLError, OSError) as e:
        log.warning("Local backend POST failed: %s", e)
    if REMOTE_BACKEND_URL:
        req2 = Request(REMOTE_BACKEND_URL, data=payload,
                       headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urlopen(req2, timeout=10): pass
        except (URLError, OSError): pass
    return ok

async def handle_client(reader, writer):
    peer = writer.get_extra_info("peername")
    log.info("Connection from %s", peer)
    sock = writer.get_extra_info("socket")
    if sock:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        log.info("  TCP_NODELAY enabled")
    sn = "UNKNOWN"
    last_forward = 0.0
    time_sync_count = 0
    buf = bytearray()
    try:
        while True:
            try: data = await asyncio.wait_for(reader.read(4096), timeout=IDLE_TIMEOUT)
            except asyncio.TimeoutError:
                log.info("sn=%s idle timeout, closing", sn); break
            if not data: break
            log.info("sn=%s << RECV %d bytes: %s", sn, len(data), data.hex())
            buf.extend(data)
            while len(buf) >= 6:
                if buf[0] != FRAME_START:
                    idx = buf.find(bytes([FRAME_START]), 1)
                    if idx == -1:
                        skipped = bytes(buf); buf.clear()
                        log.info("sn=%s  !! skipped %d non-frame bytes: %s", sn, len(skipped), skipped.hex())
                        break
                    else:
                        log.info("sn=%s  !! skipped %d non-frame bytes: %s", sn, idx, bytes(buf[:idx]).hex())
                        del buf[:idx]; continue
                if len(buf) < 2: break
                total = 2 + buf[1]
                if len(buf) < total: break
                raw = bytes(buf[:total]); del buf[:total]
                frame = parse_frame(raw)
                if frame is None:
                    log.warning("sn=%s BAD FRAME (checksum?): %s", sn, raw.hex()); continue
                cmd, seq, payload = frame["cmd"], frame["seq"], frame["payload"]
                log.info("sn=%s << FRAME cmd=%s seq=0x%02X payload(%dB)=%s",
                         sn, cmd_name(cmd), seq, len(payload), payload.hex() if payload else "(empty)")

                if cmd == CMD_LOGIN:
                    info = parse_login(frame)
                    sn = info.get("sn", "UNKNOWN"); time_sync_count = 0
                    log.info("  Login from sn=%s", sn)
                    ack = build_login_ack(seq)
                    log.info("sn=%s >> SEND LOGIN_ACK: %s", sn, ack.hex())
                    writer.write(ack); await writer.drain()

                elif cmd == CMD_DEVICE_INFO:
                    info = parse_device_info(frame)
                    dev_sn = info.get("sn", sn)
                    log.info("  Device info sn=%s firmware=%s type=%s",
                             dev_sn, info.get("firmware", "?"), info.get("device_type", "?"))
                    if dev_sn != "UNKNOWN": sn = dev_sn
                    ack = build_device_info_ack(seq)
                    log.info("sn=%s >> SEND DEVICE_INFO_ACK: %s", sn, ack.hex())
                    writer.write(ack); await writer.drain()

                elif cmd == CMD_TIME_SYNC:
                    time_sync_count += 1
                    log.info("  Time sync request #%d (payload=%s)",
                             time_sync_count, payload.hex() if payload else "(empty)")
                    if SKIP_TIME_ACK:
                        log.info("  GLK_SKIP_TIME_ACK=1 — NOT sending ACK")
                    else:
                        ack = get_time_sync_ack(seq)
                        log.info("sn=%s >> SEND TIME_SYNC_ACK (#%d): %s", sn, time_sync_count, ack.hex())
                        writer.write(ack); await writer.drain()

                elif cmd == CMD_REALTIME:
                    vitals = parse_realtime(frame)
                    if vitals:
                        now = time.monotonic()
                        if now - last_forward >= FORWARD_INTERVAL:
                            last_forward = now
                            log.info("  VITALS sn=%s HR=%s RR=%s status=%s battery=%s",
                                     sn, vitals.get("heart_rate"), vitals.get("respiration_rate"),
                                     vitals.get("status"), vitals.get("battery_level"))
                            asyncio.get_event_loop().run_in_executor(None, forward_to_backend, sn, vitals)

                elif cmd == CMD_SLEEP_STAGE:
                    log.info("  Sleep stage frame (%d bytes)", len(raw))
                    asyncio.get_event_loop().run_in_executor(
                        None, forward_to_backend, sn, {"type": "sleep_stage", "raw_hex": raw.hex()})

                elif cmd == CMD_EMERGENCY:
                    log.warning("  EMERGENCY frame from sn=%s!", sn)
                    asyncio.get_event_loop().run_in_executor(
                        None, forward_to_backend, sn, {"type": "emergency", "raw_hex": raw.hex()})

                else:
                    log.info("  UNKNOWN cmd=0x%02X (%d payload bytes)", cmd, len(payload))

    except (ConnectionResetError, BrokenPipeError):
        log.info("sn=%s connection reset (time_syncs=%d)", sn, time_sync_count)
    except Exception: log.exception("sn=%s unexpected error", sn)
    finally:
        writer.close()
        try: await writer.wait_closed()
        except: pass
        log.info("sn=%s disconnected (time_syncs=%d)", sn, time_sync_count)

async def run_server():
    server = await asyncio.start_server(handle_client, "0.0.0.0", LISTEN_PORT)
    addrs = ", ".join(str(s.getsockname()) for s in server.sockets)
    log.info("GLK bridge listening on %s", addrs)
    log.info("  Time format: %s  |  Skip time ACK: %s", TIME_FORMAT, SKIP_TIME_ACK)
    stop = asyncio.Event()
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, lambda: stop.set())
    async with server: await stop.wait()
    log.info("GLK bridge stopped")

def main():
    log.info("Starting GLK bridge (port=%d, local=%s, remote=%s, interval=%.0fs)",
             LISTEN_PORT, LOCAL_BACKEND_URL, REMOTE_BACKEND_URL or "(none)", FORWARD_INTERVAL)
    asyncio.run(run_server())

if __name__ == "__main__":
    main()
