@echo off
REM Run-full-parity.bat — Double-click to update Pi to latest v4
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "run-full-parity.ps1"
pause
