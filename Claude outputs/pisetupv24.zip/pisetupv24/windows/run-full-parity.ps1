# run-full-parity.ps1 — Re-run setup to bring running Pi to latest v4
param(
    [string]$PiIp = "192.168.50.106",
    [string]$PiUser = "pi"
)

$ScriptDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

Write-Host "Awesom Living - Full Parity Update (v4)" -ForegroundColor Cyan

if (-not (Test-Connection -ComputerName $PiIp -Count 1 -Quiet -TimeoutSeconds 3)) {
    Write-Host "ERROR: Pi at ${PiIp} not reachable." -ForegroundColor Red
    exit 1
}

scp -o StrictHostKeyChecking=no "${ScriptDir}\setup-pi-fresh.sh" "${PiUser}@${PiIp}:/home/${PiUser}/"
ssh -o StrictHostKeyChecking=no -t "${PiUser}@${PiIp}" "chmod +x /home/${PiUser}/setup-pi-fresh.sh && /home/${PiUser}/setup-pi-fresh.sh"

Write-Host "Full parity update complete!" -ForegroundColor Green
