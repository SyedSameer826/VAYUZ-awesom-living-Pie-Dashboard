# deploy-pi.ps1 — Deploy setup to Pi from Windows (PowerShell)
# Usage: .\deploy-pi.ps1 [PI_IP]

param(
    [string]$PiIp = "192.168.50.106",
    [string]$PiUser = "pi"
)

$ScriptDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Awesom Living - Deploy to Pi (v4)" -ForegroundColor Cyan
Write-Host "  Pi:     ${PiUser}@${PiIp}" -ForegroundColor Cyan
Write-Host "  Source: ${ScriptDir}" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Check connectivity
Write-Host "Checking if Pi is reachable..."
if (-not (Test-Connection -ComputerName $PiIp -Count 1 -Quiet -TimeoutSeconds 3)) {
    Write-Host "ERROR: Pi at ${PiIp} is not reachable." -ForegroundColor Red
    Write-Host "Check: Is the Pi powered on? Same network?"
    exit 1
}
Write-Host "  Pi is reachable!" -ForegroundColor Green

# Copy files via SCP
Write-Host ""
Write-Host "Copying setup files to Pi..."
scp -o StrictHostKeyChecking=no "${ScriptDir}\setup-pi-fresh.sh" "${PiUser}@${PiIp}:/home/${PiUser}/"

Write-Host "Copying GLK bridge files..."
ssh -o StrictHostKeyChecking=no "${PiUser}@${PiIp}" "mkdir -p /home/${PiUser}/glk-setup"
scp -o StrictHostKeyChecking=no "${ScriptDir}\glk\glk_bridge.py" "${ScriptDir}\glk\glk_protocol.py" "${ScriptDir}\glk\glk_provision.py" "${PiUser}@${PiIp}:/home/${PiUser}/glk-setup/"

Write-Host ""
Write-Host "Running setup script on Pi (10-20 min on first run)..." -ForegroundColor Yellow
ssh -o StrictHostKeyChecking=no -t "${PiUser}@${PiIp}" "chmod +x /home/${PiUser}/setup-pi-fresh.sh && /home/${PiUser}/setup-pi-fresh.sh"

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Deployment complete!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
