#!/usr/bin/env bash
# set-static-ip.sh — Set a static IP on the Pi (run ON the Pi via SSH)
# From Windows: ssh pi@<pi-ip> "bash -s" < set-static-ip.sh

set -e

STATIC_IP="${1:-192.168.50.106}"
GATEWAY="${2:-192.168.50.1}"
DNS="${3:-8.8.8.8}"
INTERFACE="eth0"

echo "Setting static IP: ${STATIC_IP} on ${INTERFACE}"

if [ -f /etc/dhcpcd.conf ]; then
    sudo sed -i "/^interface ${INTERFACE}/,/^$/d" /etc/dhcpcd.conf
    sudo tee -a /etc/dhcpcd.conf > /dev/null << EOF

interface ${INTERFACE}
static ip_address=${STATIC_IP}/24
static routers=${GATEWAY}
static domain_name_servers=${DNS}
EOF
    sudo systemctl restart dhcpcd
else
    sudo nmcli con mod "Wired connection 1" \
        ipv4.addresses "${STATIC_IP}/24" \
        ipv4.gateway "${GATEWAY}" \
        ipv4.dns "${DNS}" \
        ipv4.method manual
    sudo nmcli con up "Wired connection 1"
fi

echo "Static IP set to ${STATIC_IP}"
