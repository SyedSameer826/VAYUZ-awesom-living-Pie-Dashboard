@echo off
REM Run-deploy-pi.bat — Double-click to deploy to Pi from Windows
REM Launches the PowerShell deploy script

cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "deploy-pi.ps1"
pause
