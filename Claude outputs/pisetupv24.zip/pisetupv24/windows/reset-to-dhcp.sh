#!/usr/bin/env bash
# reset-to-dhcp.sh — Remove static IP, go back to DHCP (run ON the Pi)

set -e
INTERFACE="eth0"

if [ -f /etc/dhcpcd.conf ]; then
    sudo sed -i "/^interface ${INTERFACE}/,/^$/d" /etc/dhcpcd.conf
    sudo systemctl restart dhcpcd
else
    sudo nmcli con mod "Wired connection 1" ipv4.method auto
    sudo nmcli con up "Wired connection 1"
fi

echo "DHCP restored. New IP: $(hostname -I | awk '{print $1}')"
