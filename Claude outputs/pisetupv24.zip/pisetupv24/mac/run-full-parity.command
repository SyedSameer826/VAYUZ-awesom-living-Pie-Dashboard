#!/usr/bin/env bash
# run-full-parity.command — Re-run setup to bring a running Pi to latest v4
# Use this when the Pi is already running but needs the latest patches.
# Double-click in Finder to run.

set -e

PI_IP="${1:-192.168.50.106}"
PI_USER="pi"
SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "============================================"
echo "  Awesom Living — Full Parity Update (v4)"
echo "  Pi: ${PI_USER}@${PI_IP}"
echo "============================================"
echo ""

if ! ping -c 1 -W 3 "$PI_IP" &>/dev/null; then
    echo "ERROR: Pi at ${PI_IP} is not reachable."
    exit 1
fi

# Copy and run
scp -o StrictHostKeyChecking=no \
    "${SCRIPT_DIR}/setup-pi-fresh.sh" \
    "${PI_USER}@${PI_IP}:/home/${PI_USER}/"

ssh -o StrictHostKeyChecking=no -t "${PI_USER}@${PI_IP}" \
    "chmod +x /home/${PI_USER}/setup-pi-fresh.sh && /home/${PI_USER}/setup-pi-fresh.sh"

echo ""
echo "Full parity update complete!"
