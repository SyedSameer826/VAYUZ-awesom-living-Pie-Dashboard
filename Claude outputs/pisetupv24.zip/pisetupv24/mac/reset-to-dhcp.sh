#!/usr/bin/env bash
# reset-to-dhcp.sh — Remove static IP and go back to DHCP (run ON the Pi)
#
# Usage: ssh pi@<pi-ip> "bash -s" < reset-to-dhcp.sh

set -e

INTERFACE="eth0"

echo "Resetting ${INTERFACE} to DHCP..."

if [ -f /etc/dhcpcd.conf ]; then
    sudo sed -i "/^interface ${INTERFACE}/,/^$/d" /etc/dhcpcd.conf
    echo "Removed static config from /etc/dhcpcd.conf"
    sudo systemctl restart dhcpcd
else
    sudo nmcli con mod "Wired connection 1" ipv4.method auto
    sudo nmcli con up "Wired connection 1"
fi

NEW_IP=$(hostname -I | awk '{print $1}')
echo "DHCP restored. New IP: ${NEW_IP}"
echo "Reconnect: ssh pi@${NEW_IP}"
