#!/usr/bin/env bash
# deploy-pi.command — One-click Pi deployment from macOS
# Double-click this file in Finder to deploy setup-pi-fresh.sh to the Pi.
#
# Prerequisites:
#   - Pi is on the local network at the IP below (edit if different)
#   - SSH is enabled on the Pi (default user: pi, password: 1234)
#   - This file is in the same directory as setup-pi-fresh.sh and glk/

set -e

PI_IP="${1:-192.168.50.106}"
PI_USER="pi"
PI_PASS="1234"
SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "============================================"
echo "  Awesom Living — Deploy to Pi (v4)"
echo "  Pi:     ${PI_USER}@${PI_IP}"
echo "  Source: ${SCRIPT_DIR}"
echo "============================================"
echo ""

# Check if Pi is reachable
echo "Checking if Pi is reachable at ${PI_IP}..."
if ! ping -c 1 -W 3 "$PI_IP" &>/dev/null; then
    echo "ERROR: Pi at ${PI_IP} is not reachable."
    echo "Check: Is the Pi powered on? Is it on the same network?"
    echo ""
    echo "To use a different IP: ./deploy-pi.command 192.168.x.x"
    exit 1
fi
echo "  Pi is reachable!"
echo ""

# Copy files to Pi
echo "Copying setup files to Pi..."
scp -o StrictHostKeyChecking=no \
    "${SCRIPT_DIR}/setup-pi-fresh.sh" \
    "${PI_USER}@${PI_IP}:/home/${PI_USER}/"

echo "Copying GLK bridge files..."
ssh -o StrictHostKeyChecking=no "${PI_USER}@${PI_IP}" "mkdir -p /home/${PI_USER}/glk-setup"
scp -o StrictHostKeyChecking=no \
    "${SCRIPT_DIR}/glk/glk_bridge.py" \
    "${SCRIPT_DIR}/glk/glk_protocol.py" \
    "${SCRIPT_DIR}/glk/glk_provision.py" \
    "${PI_USER}@${PI_IP}:/home/${PI_USER}/glk-setup/"

echo ""
echo "Files copied. Running setup script on Pi..."
echo "(This will take 10-20 minutes on first run)"
echo ""

# Run setup script on Pi
ssh -o StrictHostKeyChecking=no -t "${PI_USER}@${PI_IP}" \
    "chmod +x /home/${PI_USER}/setup-pi-fresh.sh && /home/${PI_USER}/setup-pi-fresh.sh"

echo ""
echo "============================================"
echo "  Deployment complete!"
echo "============================================"
