#!/usr/bin/env bash
# set-static-ip.sh — Set a static IP on the Pi (run ON the Pi via SSH)
#
# Usage: ssh pi@<pi-ip> "bash -s" < set-static-ip.sh
# Or copy to Pi and run: ./set-static-ip.sh

set -e

STATIC_IP="${1:-192.168.50.106}"
GATEWAY="${2:-192.168.50.1}"
DNS="${3:-8.8.8.8}"
INTERFACE="eth0"

echo "Setting static IP: ${STATIC_IP} on ${INTERFACE}"
echo "  Gateway: ${GATEWAY}"
echo "  DNS:     ${DNS}"

# Check if dhcpcd.conf exists (Raspberry Pi OS uses dhcpcd)
if [ -f /etc/dhcpcd.conf ]; then
    # Remove any existing static config for this interface
    sudo sed -i "/^interface ${INTERFACE}/,/^$/d" /etc/dhcpcd.conf

    # Append new static config
    sudo tee -a /etc/dhcpcd.conf > /dev/null << EOF

interface ${INTERFACE}
static ip_address=${STATIC_IP}/24
static routers=${GATEWAY}
static domain_name_servers=${DNS}
EOF

    echo "Static IP configured in /etc/dhcpcd.conf"
    echo "Restarting dhcpcd..."
    sudo systemctl restart dhcpcd
else
    # NetworkManager-based (newer Raspberry Pi OS)
    echo "Using NetworkManager (nmcli)..."
    sudo nmcli con mod "Wired connection 1" \
        ipv4.addresses "${STATIC_IP}/24" \
        ipv4.gateway "${GATEWAY}" \
        ipv4.dns "${DNS}" \
        ipv4.method manual
    sudo nmcli con up "Wired connection 1"
fi

echo ""
echo "Static IP set to ${STATIC_IP}"
echo "You may need to reconnect: ssh pi@${STATIC_IP}"
